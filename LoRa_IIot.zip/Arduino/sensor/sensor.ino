#include <SPI.h>

#include <LoRa.h>

#include <DHT.h>

#include <RTCZero.h>


#define DHTPIN    6
#define DHTTYPE   DHT22
#define LORA_BAND 868E6

DHT dht(DHTPIN, DHTTYPE);

RTCZero rtc;
ode

String xorKey = "D51";


String xorCrypt(const String &input) {

  String msg = input;

  for (int i = 0; i < msg.length(); i++) {

    msg[i] = msg[i] ^ xorKey[i % xorKey.length()];

  }

  return msg;

}



String getTimestamp() {

  char buffer[25];

  sprintf(buffer, "%02d-%02d-20%02d %02d:%02d:%02d",

          rtc.getDay(),

          rtc.getMonth(),

          rtc.getYear(),

          rtc.getHours(),

          rtc.getMinutes(),

          rtc.getSeconds());

  return String(buffer);

}



void setup() {

  Serial.begin(9600);

  while (!Serial);



  Serial.println("Sensor Node – DHT22 + RTC + LoRa");



  dht.begin();

  rtc.begin(); 


  if (!LoRa.begin(LORA_BAND)) {

    Serial.println("Starting LoRa failed!");

    while (1);

  }



  LoRa.setSyncWord(0xF3); 

  Serial.println("LoRa init done. Waiting for requests...");

}



void loop() {

  int packetSize = LoRa.parsePacket();

  if (!packetSize) {

    return; 

  

  String encReq = "";

  while (LoRa.available()) {

    encReq += (char)LoRa.read();

  }

  Serial.print("\nEncrypted request received: ");

  Serial.println(encReq);

  String req = xorCrypt(encReq);

  Serial.print("Decrypted request: ");

  Serial.println(req);



  if (req == "READ") {

    Serial.println("Valid READ request – reading DHT22 and RTC...");



    float temperature = dht.readTemperature();
    float humidity    = dht.readHumidity();



    if (isnan(temperature) || isnan(humidity)) {

      Serial.println("DHT read error – not sending reply.");

      return;

    }



    String timestamp = getTimestamp();

    String msg = "Time:" + timestamp +

                 ",Temp:" + String(temperature, 2) +

                 ",Hum:"  + String(humidity, 2);



    Serial.print("Plain reply: ");

    Serial.println(msg);


    String encMsg = xorCrypt(msg);

    Serial.print("Encrypted reply: ");

    Serial.println(encMsg);
    LoRa.beginPacket();

    LoRa.print(encMsg);

    LoRa.endPacket();



    Serial.println("Reply sent.\n");

  } else {

    Serial.println("Unknown request – ignoring.\n");

  }

}