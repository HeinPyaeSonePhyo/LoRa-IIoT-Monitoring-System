#include <SPI.h>

#include <LoRa.h>



#define LORA_BAND 868E6

const int buttonPin       = 2;

int       lastButtonState = HIGH;


String xorKey = "D51";

String xorCrypt(const String &input) {

  String msg = input;

  for (int i = 0; i < msg.length(); i++) {

    msg[i] = msg[i] ^ xorKey[i % xorKey.length()];

  }

  return msg;

}


void setup() {

  pinMode(buttonPin, INPUT_PULLUP);



  Serial.begin(9600);

  while (!Serial);



  Serial.println("Trigger Node – LoRa Button");



  if (!LoRa.begin(LORA_BAND)) {

    Serial.println("Starting LoRa failed!");

    while (1);

  }



  LoRa.setSyncWord(0xF3); 

  Serial.println("LoRa init done. Waiting for button press...");

}



void loop() {

  int buttonState = digitalRead(buttonPin);
  if (buttonState == LOW && lastButtonState == HIGH) {

    Serial.println("\nButton pressed – sending READ request...");





    String request  = "READ";

    String encReq   = xorCrypt(request);

    LoRa.beginPacket();

    LoRa.print(encReq);

    LoRa.endPacket();

    Serial.print("Encrypted request sent: ");

    Serial.println(encReq);




    unsigned long startTime = millis();

    const unsigned long timeout = 3000; 

    String encReply = "";

    bool   gotReply = false;

    Serial.println("Waiting for reply from sensor...");
    while (millis() - startTime < timeout) {

      int packetSize = LoRa.parsePacket();

      if (packetSize) {
        while (LoRa.available()) {

          encReply += (char)LoRa.read();
        }
        gotReply = true;
        break;
      }

    }



    if (!gotReply) {

      Serial.println("No reply received from sensor (timeout).\n");

    } else {

      Serial.print("Encrypted reply: ");

      Serial.println(encReply);



  

      String reply = xorCrypt(encReply);

      Serial.print("Decrypted reply: ");

      Serial.println(reply);



      int timePos = reply.indexOf("Time:");

      int tempPos = reply.indexOf("Temp:");

      int humPos  = reply.indexOf("Hum:");



      if (timePos == -1 || tempPos == -1 || humPos == -1) {

        Serial.println("Could not parse fields.\n");

      } else {

   

        String timeStr = reply.substring(timePos + 5, tempPos - 1);   

        String tempStr = reply.substring(tempPos + 5, humPos - 1);  

        String humStr  = reply.substring(humPos + 4);               



        Serial.println("\n----- DATA RECEIVED FROM SENSOR -----");

        Serial.println("Time:        " + timeStr);

        Serial.println("Temperature: " + tempStr + " °C");

        Serial.println("Humidity:    " + humStr + " %");

        Serial.println("-------------------------------------\n");

      }

    }

  }



  lastButtonState = buttonState;

  delay(50);  

}